
x=0;

continue;

return x;

break;

return x+1;

return 2*x;

print x;

