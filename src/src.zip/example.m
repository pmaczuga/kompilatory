a = [[1,2,3],
     [4,5,6],
     [7,8,9]];

b = -a;

print b;

print a .+ b;

print eye(4);

print ones(4) .* 4;

c = [2,2,2];

print a * c;